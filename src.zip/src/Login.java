import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Login extends Application {
    @Override
    public void start(Stage primaryStage) {
        showWelcomePage(primaryStage); // Start with the Welcome Page
    }

    private void showWelcomePage(Stage primaryStage) {
        Button getStartedButton = new Button("Get Started-->");
        getStartedButton.setStyle(
                "-fx-font-size: 40px; " +
                        "-fx-text-fill: white; " +
                        "-fx-background-color: black; " +
                        "-fx-padding: 30px 60px; " +
                        "-fx-border-width: 6px; " +
                        "-fx-border-radius: 20px; " +
                        "-fx-border-color: cyan;"
        );

        DropShadow glowEffect = new DropShadow();
        glowEffect.setRadius(25);
        glowEffect.setSpread(0.8);
        glowEffect.setColor(Color.CYAN);
        getStartedButton.setEffect(glowEffect);

        Timeline glowAnimation = new Timeline(
                new KeyFrame(Duration.seconds(0.3), e -> {
                    glowEffect.setColor(Color.BLUE);
                    getStartedButton.setStyle("-fx-border-color: blue; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                }),
                new KeyFrame(Duration.seconds(0.6), e -> {
                    glowEffect.setColor(Color.PURPLE);
                    getStartedButton.setStyle("-fx-border-color: purple; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                }),
                new KeyFrame(Duration.seconds(0.9), e -> {
                    glowEffect.setColor(Color.CYAN);
                    getStartedButton.setStyle("-fx-border-color: cyan; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                })
        );
        glowAnimation.setCycleCount(Animation.INDEFINITE);
        glowAnimation.play();

        ScaleTransition pulse = new ScaleTransition(Duration.seconds(0.8), getStartedButton);
        pulse.setByX(0.15);
        pulse.setByY(0.15);
        pulse.setCycleCount(Animation.INDEFINITE);
        pulse.setAutoReverse(true);
        pulse.play();

        getStartedButton.setOnAction(e -> showLoginPage(primaryStage));

        StackPane root = new StackPane(getStartedButton);
        root.setStyle("-fx-background-color: black;");
        Scene scene = new Scene(root, 500, 400);

        primaryStage.setTitle("Welcome Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showLoginPage(Stage primaryStage) {
        Label userLabel = new Label("Username:");
        TextField userTextField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Button loginButton = new Button("Login");
        Label messageLabel = new Label();

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(userLabel, 0, 0);
        gridPane.add(userTextField, 1, 0);
        gridPane.add(passLabel, 0, 1);
        gridPane.add(passField, 1, 1);
        gridPane.add(loginButton, 1, 2);
        gridPane.add(messageLabel, 1, 3);

        loginButton.setOnAction(e -> {
            String username = userTextField.getText();
            String password = passField.getText();
            if ("user".equals(username) && "pass".equals(password)) {
                showNextPage(primaryStage);
            } else {
                messageLabel.setText("Invalid credentials, try again.");
            }
        });

        StackPane root = new StackPane(gridPane);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
    }

    private void showNextPage(Stage primaryStage) {
        VBox menu = new VBox(15);
        menu.setAlignment(Pos.CENTER);

        Button adminButton = new Button("Admin");
        Button investorButton = new Button("Investor");
        Button mentorButton = new Button("Mentor");
        Button founderButton = new Button("Startup Founder");

        applyButtonAnimation(adminButton);
        applyButtonAnimation(investorButton);
        applyButtonAnimation(mentorButton);
        applyButtonAnimation(founderButton);

        adminButton.setOnAction(e -> showDashboard(primaryStage, "Admin"));
        investorButton.setOnAction(e -> showDashboard(primaryStage, "Investor"));
        mentorButton.setOnAction(e -> showDashboard(primaryStage, "Mentor"));
        founderButton.setOnAction(e -> showDashboard(primaryStage, "Startup Founder"));

        menu.getChildren().addAll(adminButton, investorButton, mentorButton, founderButton);
        StackPane root = new StackPane(menu);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Dashboard");
        primaryStage.setScene(scene);
    }

    private void applyButtonAnimation(Button button) {
        button.setStyle("-fx-font-size: 24px; -fx-text-fill: white; -fx-background-color: black; -fx-border-color: cyan; -fx-border-radius: 15px;");

        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.CYAN);
        button.setEffect(shadow);

        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.8), button);
        scaleTransition.setByX(0.1);
        scaleTransition.setByY(0.1);
        scaleTransition.setCycleCount(Animation.INDEFINITE);
        scaleTransition.setAutoReverse(true);
        scaleTransition.play();
    }

    private void showDashboard(Stage primaryStage, String userType) {
        Label label = new Label("Welcome, " + userType + "!");
        StackPane root = new StackPane(label);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle(userType + " Dashboard");
        primaryStage.setScene(scene);
    }

    public static void main(String[] args) {
        launch(args);
    }
}