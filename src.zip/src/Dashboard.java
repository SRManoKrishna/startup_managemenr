import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Dashboard {
    public void show(Stage primaryStage, String userType) {
        Label label = new Label("Welcome, " + userType + "!");
        StackPane root = new StackPane(label);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle(userType + " Dashboard");
        primaryStage.setScene(scene);
    }
}
