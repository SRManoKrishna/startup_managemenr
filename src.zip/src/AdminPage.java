import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AdminPage {
    public void show(Stage stage) {
        TabPane tabPane = new TabPane();

        // Overview (placeholders for auto-filled data)
        VBox overview = new VBox(10,
                new Label("Total Startups: [Auto]"),
                new Label("Total Investors: [Auto]"),
                new Label("Total Mentors: [Auto]"),
                new Label("Total Funding: [Auto]"),
                new Label("Events & Programs: [Auto]")
        );
        overview.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Overview", overview));

        // Applications Management
        VBox applications = new VBox(10,
                new Label("Pending Applications [Mock Table]"),
                new Button("Approve"),
                new Button("Reject"),
                new Button("Assign Mentor")
        );
        applications.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Applications", applications));

        // Investor Management
        TextField invName = new TextField();
        invName.setPromptText("Name");

        TextField invEmail = new TextField();
        invEmail.setPromptText("Email");

        TextField invExpertise = new TextField();
        invExpertise.setPromptText("Expertise Area");

        TextField invFunding = new TextField();
        invFunding.setPromptText("Available Funding");

        VBox investor = new VBox(10,
                invName, invEmail, invExpertise, invFunding,
                new Button("Add Investor"),
                new Button("View/Edit/Delete Investor")
        );
        investor.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Investors", investor));

        // Mentor Management
        TextField menName = new TextField();
        menName.setPromptText("Name");

        TextField menEmail = new TextField();
        menEmail.setPromptText("Email");

        TextField menExpertise = new TextField();
        menExpertise.setPromptText("Expertise");

        TextField menAvailability = new TextField();
        menAvailability.setPromptText("Availability");

        VBox mentor = new VBox(10,
                menName, menEmail, menExpertise, menAvailability,
                new Button("Add Mentor"),
                new Button("View/Edit/Delete Mentor"),
                new Button("Assign to Startup")
        );
        mentor.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Mentors", mentor));

        // Events & Programs
        TextField evtTitle = new TextField();
        evtTitle.setPromptText("Title");

        TextArea evtDescription = new TextArea();
        evtDescription.setPromptText("Description");

        TextField evtDate = new TextField();
        evtDate.setPromptText("Date");

        TextField evtLocation = new TextField();
        evtLocation.setPromptText("Location");

        VBox events = new VBox(10,
                evtTitle, evtDescription, evtDate, evtLocation,
                new Button("Add Program/Event"),
                new Button("View Upcoming Events")
        );
        events.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Programs", events));

        // Reports
        ComboBox<String> reportType = new ComboBox<>();
        reportType.getItems().addAll("Funding", "Startups", "Mentor Activity");
        reportType.setPromptText("Generate Report For");

        VBox reports = new VBox(10,
                reportType,
                new Button("Export as PDF/CSV")
        );
        reports.setPadding(new Insets(10));
        tabPane.getTabs().add(new Tab("Reports", reports));

        // Back button
        Button back = new Button("Back");
        back.setOnAction(e -> new DashboardMenu().show(stage));

        VBox root = new VBox(tabPane, back);
        Scene scene = new Scene(root, 600, 500);
        stage.setTitle("Admin Dashboard");
        stage.setScene(scene);
        stage.show(); // You missed this!
    }
}
