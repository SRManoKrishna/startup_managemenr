import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MentorPage {
    public void show(Stage stage) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Label heading = new Label("Mentor Profile");

        TextField name = new TextField();
        name.setPromptText("Name");

        TextField email = new TextField();
        email.setPromptText("Email");

        TextField expertise = new TextField();
        expertise.setPromptText("Expertise");

        TextField hours = new TextField();
        hours.setPromptText("Available Hours");

        Label assigned = new Label("Assigned Startups:");
        ListView<String> assignedList = new ListView<>();
        assignedList.getItems().addAll("Startup A", "Startup B");

        Button sessionBtn = new Button("Start Session");

        Label sessionLabel = new Label("Mentorship Session:");

        TextField startup = new TextField();
        startup.setPromptText("Startup Name");

        TextField date = new TextField();
        date.setPromptText("Date");

        TextArea notes = new TextArea();
        notes.setPromptText("Session Notes");

        TextField nextSteps = new TextField();
        nextSteps.setPromptText("Next Steps");

        Button save = new Button("Save Session");

        Label feedbackLabel = new Label("Submit Feedback:");
        ComboBox<String> feedbackCategory = new ComboBox<>();
        feedbackCategory.getItems().addAll("Progress", "Team", "Pitch Quality");
        feedbackCategory.setPromptText("Select Category");

        TextArea comment = new TextArea();
        comment.setPromptText("Comments");

        Slider rating = new Slider(1, 5, 3);
        rating.setShowTickLabels(true);
        rating.setShowTickMarks(true);

        Button submitFeedback = new Button("Submit Feedback");

        Button back = new Button("Back");
        back.setOnAction(e -> new DashboardMenu().show(stage));

        layout.getChildren().addAll(
                heading, name, email, expertise, hours,
                assigned, assignedList, sessionBtn,
                sessionLabel, startup, date, notes, nextSteps, save,
                feedbackLabel, feedbackCategory, comment, rating, submitFeedback,
                back
        );

        stage.setScene(new Scene(layout, 600, 700));
        stage.setTitle("Mentor Dashboard");
        stage.show();
    }
}
