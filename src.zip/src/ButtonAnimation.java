import javafx.animation.Animation;
import javafx.animation.ScaleTransition;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class ButtonAnimation {
    public static void apply(Button button) {
        button.setStyle("-fx-font-size: 24px; -fx-text-fill: white; -fx-background-color: black; -fx-border-color: cyan; -fx-border-radius: 15px;");

        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.CYAN);
        button.setEffect(shadow);

        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.8), button);
        scaleTransition.setByX(0.1);
        scaleTransition.setByY(0.1);
        scaleTransition.setCycleCount(Animation.INDEFINITE);
        scaleTransition.setAutoReverse(true);
        scaleTransition.play();
    }
}
