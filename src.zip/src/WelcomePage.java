import javafx.animation.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class WelcomePage {
    public void show(Stage primaryStage) {
        Button getStartedButton = new Button("Get Started-->");
        getStartedButton.setStyle(
                "-fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black; " +
                        "-fx-padding: 30px 60px; -fx-border-width: 6px; -fx-border-radius: 20px; " +
                        "-fx-border-color: cyan;"
        );

        DropShadow glowEffect = new DropShadow();
        glowEffect.setRadius(25);
        glowEffect.setSpread(0.8);
        glowEffect.setColor(Color.CYAN);
        getStartedButton.setEffect(glowEffect);

        Timeline glowAnimation = new Timeline(
                new KeyFrame(Duration.seconds(0.3), e -> {
                    glowEffect.setColor(Color.BLUE);
                    getStartedButton.setStyle("-fx-border-color: blue; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                }),
                new KeyFrame(Duration.seconds(0.6), e -> {
                    glowEffect.setColor(Color.PURPLE);
                    getStartedButton.setStyle("-fx-border-color: purple; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                }),
                new KeyFrame(Duration.seconds(0.9), e -> {
                    glowEffect.setColor(Color.CYAN);
                    getStartedButton.setStyle("-fx-border-color: cyan; -fx-font-size: 40px; -fx-text-fill: white; -fx-background-color: black;");
                })
        );
        glowAnimation.setCycleCount(Animation.INDEFINITE);
        glowAnimation.play();

        ScaleTransition pulse = new ScaleTransition(Duration.seconds(0.8), getStartedButton);
        pulse.setByX(0.15);
        pulse.setByY(0.15);
        pulse.setCycleCount(Animation.INDEFINITE);
        pulse.setAutoReverse(true);
        pulse.play();

        getStartedButton.setOnAction(e -> new LoginPage().show(primaryStage));

        StackPane root = new StackPane(getStartedButton);
        root.setStyle("-fx-background-color: black;");
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Welcome Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
