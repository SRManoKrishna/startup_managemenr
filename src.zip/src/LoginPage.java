import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginPage {
    public void show(Stage primaryStage) {
        Label userLabel = new Label("Username:");
        TextField userTextField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Button loginButton = new Button("Login");
        Label messageLabel = new Label();

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(userLabel, 0, 0);
        gridPane.add(userTextField, 1, 0);
        gridPane.add(passLabel, 0, 1);
        gridPane.add(passField, 1, 1);
        gridPane.add(loginButton, 1, 2);
        gridPane.add(messageLabel, 1, 3);

        loginButton.setOnAction(e -> {
            String username = userTextField.getText();
            String password = passField.getText();
            if ("user".equals(username) && "pass".equals(password)) {
                new DashboardMenu().show(primaryStage);
            } else {
                messageLabel.setText("Invalid credentials, try again.");
            }
        });

        StackPane root = new StackPane(gridPane);
        root.setAlignment(Pos.CENTER);

        // ✅ Use full path with proper file URL format (spaces replaced with %20)
        Image bgImage = new Image("file:/D:/JAVA/JAVA%20PACKAGE/domoS/src/Login.jpg");
        BackgroundSize bgSize = new BackgroundSize(100, 100, true, true, true, false);
        BackgroundImage backgroundImage = new BackgroundImage(
                bgImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                bgSize
        );
        root.setBackground(new Background(backgroundImage));

        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
    }
}
