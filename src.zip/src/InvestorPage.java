import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class InvestorPage {
    public void show(Stage stage) {
        VBox layout = new VBox(10);

        Label heading = new Label("Investor Profile");

        TextField name = new TextField();
        name.setPromptText("Name");

        TextField email = new TextField();
        email.setPromptText("Email");

        TextField org = new TextField();
        org.setPromptText("Organization");

        TextField focus = new TextField();
        focus.setPromptText("Investment Focus");

        TextField budget = new TextField();
        budget.setPromptText("Available Budget");

        // Pitches
        Label pitchLabel = new Label("Startup Pitches:");
        ListView<String> pitches = new ListView<>();
        pitches.getItems().addAll("Startup A - HealthTech", "Startup B - EdTech");
        Button viewPitch = new Button("View Pitch");
        Button fundButton = new Button("Fund");

        // Funding
        TextField amount = new TextField();
        amount.setPromptText("Funding Amount");

        TextField comment = new TextField();
        comment.setPromptText("Comment");

        Button submitFunding = new Button("Submit Funding");

        // History
        Label historyLabel = new Label("Investment History:");
        ListView<String> history = new ListView<>();
        history.getItems().addAll("Startup A - $5000 - MVP", "Startup B - $7000 - Scaling");

        Button back = new Button("Back");
        back.setOnAction(e -> new DashboardMenu().show(stage));

        layout.getChildren().addAll(
                heading, name, email, org, focus, budget,
                pitchLabel, pitches, viewPitch, fundButton,
                amount, comment, submitFunding,
                historyLabel, history, back
        );
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        stage.setScene(new Scene(layout, 600, 600));
        stage.setTitle("Investor Dashboard");
        stage.show();
    }
}
