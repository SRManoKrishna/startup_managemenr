import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class FounderPage {
    public void show(Stage stage) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Label heading = new Label("Startup Founder");

        TextField startupName = new TextField();
        startupName.setPromptText("Startup Name");

        TextField founderName = new TextField();
        founderName.setPromptText("Founder Name");

        TextField email = new TextField();
        email.setPromptText("Email");

        TextField industry = new TextField();
        industry.setPromptText("Industry");

        TextField location = new TextField();
        location.setPromptText("Location");

        TextArea idea = new TextArea();
        idea.setPromptText("Idea Description");

        ComboBox<String> stageCombo = new ComboBox<>();
        stageCombo.getItems().addAll("Ideation", "MVP", "Scaling");
        stageCombo.setPromptText("Select Startup Stage");

        TextField teamSize = new TextField();
        teamSize.setPromptText("Team Size");

        TextField fundingNeeded = new TextField();
        fundingNeeded.setPromptText("Funding Needed");

        Label mentorAssigned = new Label("Mentor: [Name, Email, Expertise]");
        Button schedule = new Button("Schedule Session");

        Label fundingStatus = new Label("Funding Status:");
        ListView<String> fundingList = new ListView<>();
        fundingList.getItems().addAll("Investor A - $5000 - Approved");

        Label programs = new Label("Program Participation:");
        ListView<String> programList = new ListView<>();
        programList.getItems().addAll("Bootcamp A - 2024 - In Progress");

        Button submit = new Button("Submit Application");
        Button back = new Button("Back");
        back.setOnAction(e -> new DashboardMenu().show(stage));

        layout.getChildren().addAll(
                heading,
                startupName, founderName, email, industry, location,
                idea, stageCombo, teamSize, fundingNeeded, submit,
                mentorAssigned, schedule,
                fundingStatus, fundingList,
                programs, programList,
                back
        );

        stage.setScene(new Scene(layout, 600, 700));
        stage.setTitle("Founder Dashboard");
        stage.show();
    }
}
