import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DashboardMenu {
    public void show(Stage primaryStage) {
        VBox menu = new VBox(15);
        menu.setAlignment(Pos.CENTER);

        Button adminButton = new Button("Admin");
        Button investorButton = new Button("Investor");
        Button mentorButton = new Button("Mentor");
        Button founderButton = new Button("Startup Founder");
        Button logoutButton = new Button("Logout"); // ✅ Logout button added

        ButtonAnimation.apply(adminButton);
        ButtonAnimation.apply(investorButton);
        ButtonAnimation.apply(mentorButton);
        ButtonAnimation.apply(founderButton);
        ButtonAnimation.apply(logoutButton); // optional animation

        adminButton.setOnAction(e -> new AdminPage().show(primaryStage));
        investorButton.setOnAction(e -> new InvestorPage().show(primaryStage));
        mentorButton.setOnAction(e -> new MentorPage().show(primaryStage));
        founderButton.setOnAction(e -> new FounderPage().show(primaryStage));

        logoutButton.setOnAction(e -> new LoginPage().show(primaryStage)); // ✅ Go back to login

        menu.getChildren().addAll(adminButton, investorButton, mentorButton, founderButton, logoutButton);
        StackPane root = new StackPane(menu);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Dashboard");
        primaryStage.setScene(scene);
    }
}
